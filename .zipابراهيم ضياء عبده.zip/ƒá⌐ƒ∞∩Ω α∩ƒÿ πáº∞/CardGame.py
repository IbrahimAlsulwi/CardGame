from deck import DeckOfCards


class HighCardGame:
    def __init__(self):
        """Initialize the High Card game."""
        self.deck = DeckOfCards()
        self.deck.shuffle()
        self.player1_score = 0
        self.player2_score = 0

    def draw_for_player(self):
        """Draw a card for a player."""
        return self.deck.draw_card()

    def determine_winner(self, player1_card, player2_card):
        """Determine the winner between two cards."""
        if player1_card.value() > player2_card.value():
            return "Player 1 wins"
        elif player1_card.value() < player2_card.value():
            return "Player 2 wins"
        else:
            return "It's a tie"
        
        
    def update_scores(self, result):
        """Update scores based on the result."""
        if result == "Player 1 wins":
            self.player1_score += 1
        elif result == "Player 2 wins":
            self.player2_score += 1
    
    
    def print_scores(self):
        """Print the current scores."""
        print(f"Scores: Player 1 = {self.player1_score}, Player 2 = {self.player2_score}")        
    
    
    def play_round(self):
        """Play a round of High Card."""
        if len(self.deck) < 2:
    
             self.print_scores()
             self.end_game()
             return "Not enough cards to play"

        player1_card = self.draw_for_player()
        player2_card = self.draw_for_player()

        print(f"Player 1 drew: {player1_card}")
        print(f"Player 2 drew: {player2_card}")

        result = self.determine_winner(player1_card, player2_card)
        print(result)
        self.update_scores(result)
        return True
    
    
    def end_game(self):
        """End the game and declare the final winner."""
        print("Game over!")
        self.print_scores()
        if self.player1_score > self.player2_score:
            print("Player 1 wins the game!")
        elif self.player1_score < self.player2_score:
            print("Player 2 wins the game!")
        else:
            print("The game is a tie!")

game = HighCardGame()
while len(game.deck) > 1:
        input("Press Enter to play a round...")
        game.play_round()
print(game.end_game())
